ROCKET LEAGUE RANK ROULETTE V8

What's new in V8:
- The rank reveal remains visible for 3 seconds after the wheel stops.
- The roulette then fades away and stays hidden until another follow.
- If another follow arrives during a spin or reveal, it is queued and gets its own turn.

Everything else from V7 is preserved, including the rank emblem image URLs, spin animation,
confetti, and TikFinity Event API connection.

INSTALL:
1. Extract this ZIP into a NEW folder.
2. Open rocket-rank-roulette.html to test it.
3. If it looks right, update the browser/link source in TikTok LIVE Studio to use this version.
4. Keep your V6/V7 folders as backups until V8 is confirmed working.

The rank emblems load from Tracker Network's CDN, so an internet connection is needed.
TikFinity Desktop must be running on the same PC for follow events to trigger.
